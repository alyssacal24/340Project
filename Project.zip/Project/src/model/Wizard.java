package model; // Assuming package model

public class Wizard extends Character {
    public Wizard(String name) {
        // Call the super constructor with name AND class type
        super(name, "Wizard"); // CORRECTED
    }

    // Add other Wizard-specific methods or overrides if needed
}
