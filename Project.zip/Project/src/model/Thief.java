package model; // Assuming package model

public class Thief extends Character {
    public Thief(String name) {
        // Call the super constructor with name AND class type
        super(name, "Thief"); // CORRECTED
    }

    // Add other Thief-specific methods or overrides if needed
    // e.g., @Override public void displayAbilities() { ... }
}

