// src/model/Item.java
package model;

public class Item {
    private int id; // Corresponds to item_id in the database 'items' table
    private String name;
    private ItemType type;
    private int attackBonus;
    private int defenseBonus;
    private int healAmount;
    private String description; // Optional: For more details

    // Constructor - adjust as needed (e.g., if loading from DB)
    public Item(int id, String name, ItemType type, int attackBonus, int defenseBonus, int healAmount, String description) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.attackBonus = attackBonus;
        this.defenseBonus = defenseBonus;
        this.healAmount = healAmount;
        this.description = description;
    }

    // Getters for all fields
    public int getId() { return id; }
    public String getName() { return name; }
    public ItemType getType() { return type; }
    public int getAttackBonus() { return attackBonus; }
    public int getDefenseBonus() { return defenseBonus; }
    public int getHealAmount() { return healAmount; }
    public String getDescription() { return description; }

    // toString for easy display
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(name).append(" (").append(type.getDisplayName()).append(")");
        boolean hasStat = false;
        if (attackBonus > 0) {
            sb.append(" Att: +").append(attackBonus);
            hasStat = true;
        }
        if (defenseBonus > 0) {
            sb.append(hasStat ? "," : "");
            sb.append(" Def: +").append(defenseBonus);
            hasStat = true;
        }
        if (healAmount > 0) {
             sb.append(hasStat ? "," : "");
             sb.append(" Heals: ").append(healAmount).append(" HP");
             hasStat = true;
        }
        // Add description if needed/available
        // if (description != null && !description.isEmpty()) {
        //     sb.append(" Desc: ").append(description);
        // }
        return sb.toString();
    }
}
