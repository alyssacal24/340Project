package model; // Assuming package model

public class Warrior extends Character {
    public Warrior(String name) {
        // Call the super constructor with name AND class type
        super(name, "Warrior"); // CORRECTED
    }

    // Add other Warrior-specific methods or overrides if needed
}
