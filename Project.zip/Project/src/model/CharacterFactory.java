package model;

// No need to import List here anymore if the second method is removed

public class CharacterFactory {

    // Keep only the simple factory method
    public static Character createCharacter(String type, String name) {
        if (type == null || name == null) {
            return null; // Basic validation
        }
        return switch (type.toLowerCase()) {
            case "warrior" -> new Warrior(name);
            case "wizard" -> new Wizard(name);
            case "thief" -> new Thief(name);
            default -> {
                System.err.println("Warning: Unknown character type requested: " + type);
                yield null; // Use yield for switch expression
            }
        };
    }

    // --- REMOVED the second createCharacter method ---
    // It was causing type errors with List<String> vs List<Item>
    // and the controller now handles setting stats/skills/inventory directly.
    /*
    public static Character createCharacter(String type, String name, int strength, int intelligence, int agility, java.util.List<String> skills, java.util.List<String> inventory) {
        Character character = createCharacter(type, name); // Calls the first factory method
        if (character != null) { // Check if character creation was successful
            // These setters caused errors because they weren't defined in Character.java
            // character.setStrength(strength);
            // character.setIntelligence(intelligence);
            // character.setAgility(agility);
            // character.setSkills(skills);
            // This caused a type error (List<String> vs List<Item>)
            // character.setInventory(inventory);
        }
        return character;
    }
    */
}
