package model;

import java.util.List;

public class QuestionNode {
    public String question;
    public QuestionNode yes;
    public QuestionNode no;
    public List<String> skillsToAdd;
    public List<String> itemsToAdd;
    public String charClass;

    // Existing constructor for simple question nodes
    public QuestionNode(String question) {
        this.question = question;
        this.skillsToAdd = null; // Initialize lists to null or empty
        this.itemsToAdd = null;
        this.charClass = null;
        this.yes = null;
        this.no = null;
    }

    // --- NEW CONSTRUCTOR TO ADD ---
    /**
     * Constructor for intermediate nodes that add skills/items but don't define a class.
     * @param question The question text for this node.
     * @param skillsToAdd List of skills to add when reaching this node (can be null or empty).
     * @param itemsToAdd List of items to add when reaching this node (can be null or empty).
     */
    public QuestionNode(String question, List<String> skillsToAdd, List<String> itemsToAdd) {
        this.question = question;
        this.skillsToAdd = skillsToAdd;
        this.itemsToAdd = itemsToAdd;
        this.charClass = null; // Explicitly set charClass to null for intermediate nodes
        this.yes = null;       // Initialize branches to null
        this.no = null;        // Initialize branches to null
    }
    // --- END OF NEW CONSTRUCTOR ---

    // Existing constructor for final leaf nodes defining a class
    public QuestionNode(String question, List<String> skillsToAdd, List<String> itemsToAdd, String charClass){
        this.question = question;
        this.skillsToAdd = skillsToAdd;
        this.itemsToAdd = itemsToAdd;
        this.charClass = charClass;
        this.yes = null; // Leaf nodes have no further branches
        this.no = null;
    }
}
