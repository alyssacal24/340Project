// src/model/ItemType.java
package model;

public enum ItemType {
    WEAPON("Weapon"),
    ARMOR("Armor"),
    POTION("Potion"),
    QUEST("Quest Item"),
    GENERIC("Generic Item"); // Fallback type

    private final String displayName;

    ItemType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    // Optional: Helper to get enum from string (case-insensitive)
    public static ItemType fromString(String text) {
        for (ItemType b : ItemType.values()) {
            if (b.name().equalsIgnoreCase(text) || b.displayName.equalsIgnoreCase(text)) {
                return b;
            }
        }
        // Consider throwing an exception or returning a default
        System.err.println("Warning: Unknown ItemType string: " + text + ". Defaulting to GENERIC.");
        return GENERIC;
    }
}
