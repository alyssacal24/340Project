package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    // Keep your actual URL, USER, and PASSWORD
    private static final String URL = "jdbc:mysql://localhost:3306/rpg_db"; // Use your actual DB name
    private static final String USER = "root"; // Use your actual username
    private static final String PASSWORD = "p@ssw0rd"; // Use your actual password

    // Private constructor to prevent instantiation (good practice)
    private DatabaseConnection() {}

    /**
     * Establishes and returns a NEW database connection.
     * The caller is responsible for closing this connection properly
     * (e.g., using try-with-resources or a finally block).
     *
     * @return A new Connection object ready for use.
     * @throws SQLException if a database access error occurs or the url is null.
     */
    public static Connection getConnection() throws SQLException {
        // Optional: Explicitly load the driver if you encounter issues,
        // though usually not needed with modern JDBC drivers (JDBC 4.0+).
        // try {
        //     Class.forName("com.mysql.cj.jdbc.Driver");
        // } catch (ClassNotFoundException e) {
        //     // Wrap the ClassNotFoundException in an SQLException or handle differently
        //     throw new SQLException("MySQL JDBC Driver not found.", e);
        // }

        // Create and return a new connection directly
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // The getInstance() method is no longer needed.
    // The instance variable is no longer needed.
    // The connection instance variable is no longer needed.
}
