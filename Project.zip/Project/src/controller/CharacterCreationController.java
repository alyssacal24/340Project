// src/controller/CharacterCreationController.java
package controller; // Keep the package declaration

// Imports (ensure all needed are present)
import db.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.Character; // Assuming this is the Character model class
import model.CharacterFactory;
import model.Item;
import model.ItemType;

public class CharacterCreationController {

    // --- SQL Constants (Restored to Private) ---
    private static final String INSERT_CHARACTER_SQL =
        "INSERT INTO characters (name, class, strength, intelligence, agility) VALUES (?, ?, ?, ?, ?)";
    private static final String INSERT_SKILL_SQL =
        "INSERT INTO skills (character_id, skill_name) VALUES (?, ?)"; // Corrected table name
    // **** CORRECTED TABLE NAME AND COLUMN NAME FOR INVENTORY ****
    private static final String INSERT_INVENTORY_SQL =
        "INSERT INTO inventory (character_id, item_name) VALUES (?, ?)";
    private static final String SELECT_SUMMARIES_SQL =
        "SELECT id, name FROM characters ORDER BY name"; // Example query
    private static final String SELECT_CHARACTER_SQL =
        "SELECT name, class, strength, intelligence, agility FROM characters WHERE id = ?";
    private static final String SELECT_SKILLS_SQL =
        "SELECT skill_name FROM skills WHERE character_id = ?"; // Corrected table name
    // **** CORRECTED JOIN AND TABLE NAME FOR INVENTORY ****
    private static final String SELECT_INVENTORY_SQL =
        "SELECT i.item_id, i.name, i.type, i.attack_bonus, i.defense_bonus, i.heal_amount, i.description " +
        "FROM items i JOIN inventory inv ON i.name = inv.item_name WHERE inv.character_id = ?";
    private static final String SELECT_ITEM_BY_NAME_SQL =
        "SELECT item_id, name, type, attack_bonus, defense_bonus, heal_amount, description FROM items WHERE name = ?";
    private static final String DELETE_CHARACTER_SQL =
        "DELETE FROM characters WHERE id = ?";
    // Optional, if not using ON DELETE CASCADE:
    // private static final String DELETE_SKILLS_SQL = "DELETE FROM skills WHERE character_id = ?"; // Corrected table name
    // private static final String DELETE_INVENTORY_SQL = "DELETE FROM inventory WHERE character_id = ?"; // Corrected table name
    // --- END SQL Constants ---


    // Method signature is correct (accepts List<String> for itemNames)
    public Character createCharacter(String charClass, String name, int strength,
                                     int intelligence, int agility, List<String> skills,
                                     List<String> itemNames) {

        List<Item> actualItems = getItemsByNames(itemNames);

        Character character = CharacterFactory.createCharacter(charClass, name);
        if (character == null) {
             System.err.println("Controller Error: CharacterFactory failed to create character for class: " + charClass);
             return null;
        }

        character.setStrength(strength);
        character.setIntelligence(intelligence);
        character.setAgility(agility);
        character.setSkills(skills != null ? new ArrayList<>(skills) : new ArrayList<>());
        character.setInventory(actualItems);

        Character savedCharacter = saveToDatabase(character); // Call private helper

        return savedCharacter;
    }


    // This method saves the character object to the database (Restored to Private)
    private Character saveToDatabase(Character character) { // Added 'private' back
        if (character == null) {
            System.err.println("saveToDatabase error: Cannot save a null character object.");
            return null;
        }

        Connection conn = null;
        PreparedStatement pstmtChar = null;
        ResultSet generatedKeys = null;
        boolean transactionCompleted = false;

        try (Connection connection = DatabaseConnection.getConnection()) {
            conn = connection;
            conn.setAutoCommit(false);

            pstmtChar = conn.prepareStatement(INSERT_CHARACTER_SQL, Statement.RETURN_GENERATED_KEYS);
            pstmtChar.setString(1, character.getName());
            pstmtChar.setString(2, character.getCharClass());
            pstmtChar.setInt(3, character.getStrength());
            pstmtChar.setInt(4, character.getIntelligence());
            pstmtChar.setInt(5, character.getAgility());
            int affectedRows = pstmtChar.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating character failed, no rows affected.");
            }

            generatedKeys = pstmtChar.getGeneratedKeys();
            if (generatedKeys.next()) {
                int characterId = generatedKeys.getInt(1);
                character.setId(characterId);

                // Insert skills
                if (character.getSkills() != null && !character.getSkills().isEmpty()) {
                    try (PreparedStatement psSkillBatch = conn.prepareStatement(INSERT_SKILL_SQL)) {
                        for (String skill : character.getSkills()) {
                            psSkillBatch.setInt(1, characterId);
                            psSkillBatch.setString(2, skill);
                            psSkillBatch.addBatch();
                        }
                        psSkillBatch.executeBatch();
                    }
                }

                // Insert inventory
                if (character.getInventory() != null && !character.getInventory().isEmpty()) {
                     try (PreparedStatement psInvBatch = conn.prepareStatement(INSERT_INVENTORY_SQL)) {
                        for (Item item : character.getInventory()) {
                            if (item.getName() == null || item.getName().trim().isEmpty()) {
                                System.err.println("Warning: Skipping item with null or empty name during save.");
                                continue;
                            }
                            psInvBatch.setInt(1, characterId);
                            // **** Use item.getName() for INSERT_INVENTORY_SQL ****
                            psInvBatch.setString(2, item.getName());
                            psInvBatch.addBatch();
                        }
                        psInvBatch.executeBatch();
                    }
                }

                conn.commit();
                transactionCompleted = true;
                System.out.println("Character saved successfully with ID: " + characterId);

            } else {
                throw new SQLException("Creating character failed, no ID obtained.");
            }

        } catch (SQLException e) {
            System.err.println("Database error during character save: " + e.getMessage());
            if (conn != null && !transactionCompleted) {
                 try {
                     System.err.println("Rolling back transaction due to error.");
                     conn.rollback();
                 } catch (SQLException ex) {
                     System.err.println("Error during transaction rollback: " + ex.getMessage());
                 }
            }
            character = null;
        } finally {
             try { if (generatedKeys != null) generatedKeys.close(); } catch (SQLException e) { /* ignored */ }
             try { if (pstmtChar != null) pstmtChar.close(); } catch (SQLException e) { /* ignored */ }
             // Connection closed by try-with-resources
        }
        return character;
    }


    // Method to load summaries (Public is fine)
    public Map<Integer, String> loadAllCharacterSummaries() {
        Map<Integer, String> summaries = new HashMap<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(SELECT_SUMMARIES_SQL);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                summaries.put(rs.getInt("id"), rs.getString("name"));
            }
        } catch (SQLException e) {
            System.err.println("Database error loading character summaries: " + e.getMessage());
        }
        return summaries;
    }


    // Method to load details (Public is fine)
    public Character loadCharacterDetails(int characterId) {
        Character character = null;
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.println("--- Loading details for character ID: " + characterId + " ---");

            try (PreparedStatement pstmtChar = conn.prepareStatement(SELECT_CHARACTER_SQL)) {
                pstmtChar.setInt(1, characterId);
                try (ResultSet rsChar = pstmtChar.executeQuery()) {
                    if (rsChar.next()) {
                        String name = rsChar.getString("name");
                        String charClass = rsChar.getString("class");
                        int strength = rsChar.getInt("strength");
                        int intelligence = rsChar.getInt("intelligence");
                        int agility = rsChar.getInt("agility");

                        character = CharacterFactory.createCharacter(charClass, name);

                        if (character != null) {
                            character.setId(characterId);
                            character.setStrength(strength);
                            character.setIntelligence(intelligence);
                            character.setAgility(agility);

                            System.out.println("Attempting to load skills...");
                            List<String> skills = loadSkillsList(conn, characterId); // Call private helper
                            System.out.println("Skills list loaded. Size: " + (skills != null ? skills.size() : "null"));
                            character.setSkills(skills);

                            System.out.println("Attempting to load inventory...");
                            List<Item> inventory = loadInventoryList(conn, characterId); // Call private helper
                            System.out.println("Inventory list loaded. Size: " + (inventory != null ? inventory.size() : "null"));
                            character.setInventory(inventory);

                            System.out.println("Character object skills after set: " + character.getSkills());
                            System.out.println("Character object inventory after set: " + character.getInventory());
                        }
                    } else {
                        System.out.println("Character with ID " + characterId + " not found.");
                        return null;
                    }
                }
            }

        } catch (SQLException e) {
            System.err.println(">>> CAUGHT SQL EXCEPTION in loadCharacterDetails <<<");
            System.err.println("Database error loading character details for ID " + characterId + ": " + e.getMessage());
            character = null;
        } catch (IllegalArgumentException e) { // Catch potential ItemType errors
             System.err.println(">>> CAUGHT IllegalArgumentException (likely ItemType) in loadCharacterDetails <<<");
             System.err.println("Error processing item type for character ID " + characterId + ": " + e.getMessage());
             character = null;
        } finally {
             System.out.println("--- Finished loading details for character ID: " + characterId + " ---");
        }
        return character;
    }


    // Helper for Skills (Restored to Private)
    private List<String> loadSkillsList(Connection conn, int characterId) throws SQLException { // Added 'private' back
        List<String> list = new ArrayList<>();
        System.out.println("  Executing loadSkillsList with ID: " + characterId);
        try (PreparedStatement pstmt = conn.prepareStatement(SELECT_SKILLS_SQL)) {
            pstmt.setInt(1, characterId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String value = rs.getString("skill_name");
                    System.out.println("    Found skill: " + value);
                    list.add(value);
                }
            }
        } catch (SQLException e) {
             System.err.println("  >>> CAUGHT SQL EXCEPTION in loadSkillsList <<<");
             throw e;
        }
        System.out.println("  Finished loadSkillsList. List size: " + list.size());
        return list;
    }

    // Helper for Inventory (Restored to Private)
    private List<Item> loadInventoryList(Connection conn, int characterId) throws SQLException { // Added 'private' back
        List<Item> list = new ArrayList<>();
        System.out.println("  Executing loadInventoryList with ID: " + characterId);
        try (PreparedStatement pstmt = conn.prepareStatement(SELECT_INVENTORY_SQL)) {
            pstmt.setInt(1, characterId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Item item = new Item(
                        rs.getInt("item_id"),
                        rs.getString("name"),
                        ItemType.fromString(rs.getString("type")),
                        rs.getInt("attack_bonus"),
                        rs.getInt("defense_bonus"),
                        rs.getInt("heal_amount"),
                        rs.getString("description")
                    );
                    System.out.println("    Found item: " + item.toString());
                    list.add(item);
                }
            }
        } catch (SQLException e) {
             System.err.println("  >>> CAUGHT SQL EXCEPTION in loadInventoryList <<<");
             throw e;
        } catch (IllegalArgumentException e) { // Catch potential ItemType errors here too
             System.err.println("  >>> CAUGHT IllegalArgumentException (likely ItemType) in loadInventoryList <<<");
             throw new SQLException("Error parsing item type from database: " + e.getMessage(), e); // Wrap in SQLException
        }
        System.out.println("  Finished loadInventoryList. List size: " + list.size());
        return list;
    }

    // Method to get Item objects by their names (Public is fine)
    public List<Item> getItemsByNames(List<String> itemNames) {
        List<Item> items = new ArrayList<>();
        if (itemNames == null || itemNames.isEmpty()) {
            return items;
        }

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(SELECT_ITEM_BY_NAME_SQL)) {

            for (String name : itemNames) {
                if (name == null || name.trim().isEmpty()) continue;

                pstmt.setString(1, name.trim());
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        Item item = new Item(
                            rs.getInt("item_id"),
                            rs.getString("name"),
                            ItemType.fromString(rs.getString("type")),
                            rs.getInt("attack_bonus"),
                            rs.getInt("defense_bonus"),
                            rs.getInt("heal_amount"),
                            rs.getString("description")
                        );
                        items.add(item);
                    } else {
                        System.err.println("Warning: Item with name '" + name + "' not found in database 'items' table.");
                    }
                }
            }

        } catch (SQLException e) {
            System.err.println("Database error looking up items by name: " + e.getMessage());
        } catch (IllegalArgumentException e) { // Catch potential ItemType errors
             System.err.println("Error parsing item type while looking up items by name: " + e.getMessage());
        }
        return items;
    }


    // Method to delete character (Public is fine)
    public boolean deleteCharacter(int characterId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);

            // Delete the character itself
            try (PreparedStatement pstmtChar = conn.prepareStatement(DELETE_CHARACTER_SQL)) {
                pstmtChar.setInt(1, characterId);
                int affectedRows = pstmtChar.executeUpdate();

                if (affectedRows > 0) {
                    conn.commit();
                    System.out.println("Character with ID " + characterId + " deleted successfully.");
                    return true;
                } else {
                    System.out.println("Character with ID " + characterId + " not found for deletion.");
                    conn.rollback();
                    return false;
                }
            }

        } catch (SQLException e) {
            System.err.println("Database error deleting character with ID " + characterId + ": " + e.getMessage());
            return false;
        }
    }

} // End Class CharacterCreationController
