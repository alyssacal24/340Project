// src/view/MainView.java
package view;

import controller.CharacterCreationController;
import java.awt.*; // Includes BorderLayout, FlowLayout, Dimension, Font, GridLayout, Image
import java.awt.event.ActionEvent;
import java.net.URL; // Needed for loading image resources
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.*; // Includes JFrame, JLabel, JButton, JTextArea, JTextField, JPanel, JScrollPane, JOptionPane, SwingUtilities, UIManager, ImageIcon
import model.Character;
import model.QuestionNode;

public class MainView {
    private JFrame frame;
    private JTextField nameField;
    private JLabel questionLabel;
    private JButton yesButton;
    private JButton noButton;
    private JButton createAnotherButton;
    private JButton exitButton;
    private JButton viewCharactersButton;
    private JPanel panel;
    private JPanel buttonPanel;
    private JTextArea skillsArea;
    private JTextArea inventoryArea;
    private JPanel questionPanel; // Make this a field to access it later
    private JPanel statsPanel;    // Make this a field to access it later

    // **** ADDED: Label for class image ****
    private JLabel classImageLabel;
    // **** END ADDED ****

    private QuestionNode rootQuestion;
    private QuestionNode currentQuestion;
    private CharacterCreationController controller;
    private List<String> characterSkills = new ArrayList<>();
    private List<String> characterInventory = new ArrayList<>();
    private String characterClass;
    private int characterStrength;
    private int characterIntelligence;
    private int characterAgility;


    public MainView() {
        frame = new JFrame("RPG Character Creator");
        frame.setSize(600, 550); // Increased height slightly for image
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        panel = new JPanel();
        frame.add(panel);
        panel.setLayout(new BorderLayout());

        controller = new CharacterCreationController();
        createBinaryTree();
        placeComponents();

        resetCharacter();

        // frame.pack(); // Use pack() OR setSize(), pack is often better
        frame.setVisible(true);
    }

    private void placeComponents() {
        // --- Top Panel for Name Input ---
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JLabel nameLabel = new JLabel("Character Name:");
        nameField = new JTextField(20);
        nameField.addActionListener(this::startCreationProcess);

        topPanel.add(nameLabel);
        topPanel.add(nameField);
        panel.add(topPanel, BorderLayout.NORTH);

        // --- Center Panel for Question/Image/Details and Lists ---
        // Renamed from centerPanel to mainCenterPanel for clarity
        JPanel mainCenterPanel = new JPanel(new BorderLayout(0, 10));
        mainCenterPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- Panel specifically for Question/Image/Text Details ---
        questionPanel = new JPanel(new BorderLayout(5, 5)); // Added gap

        // **** Initialize Image Label ****
        classImageLabel = new JLabel();
        classImageLabel.setHorizontalAlignment(JLabel.CENTER);
        classImageLabel.setVerticalAlignment(JLabel.CENTER);
        classImageLabel.setPreferredSize(new Dimension(150, 150)); // Adjust size as needed
        classImageLabel.setVisible(false); // Initially hidden
        questionPanel.add(classImageLabel, BorderLayout.NORTH); // Image at the top
        // **** END Initialize ****

        questionLabel = new JLabel("Enter Name and Press Enter or Click 'Yes'/'No' below", JLabel.CENTER);
        questionLabel.setFont(new Font("Arial", Font.BOLD, 14));
        questionLabel.setHorizontalAlignment(JLabel.CENTER);
        questionPanel.add(questionLabel, BorderLayout.CENTER); // Text details below image

        mainCenterPanel.add(questionPanel, BorderLayout.NORTH); // Add the combined panel

        // --- Panel for the two lists (Skills and Inventory) ---
        statsPanel = new JPanel(new GridLayout(1, 2, 15, 0)); // Made field
        skillsArea = new JTextArea(8, 18);
        skillsArea.setEditable(false);
        skillsArea.setLineWrap(true);
        skillsArea.setWrapStyleWord(true);
        skillsArea.setBorder(BorderFactory.createTitledBorder("Skills Acquired"));
        inventoryArea = new JTextArea(8, 18);
        inventoryArea.setEditable(false);
        inventoryArea.setLineWrap(true);
        inventoryArea.setWrapStyleWord(true);
        inventoryArea.setBorder(BorderFactory.createTitledBorder("Inventory Acquired"));

        statsPanel.add(new JScrollPane(skillsArea));
        statsPanel.add(new JScrollPane(inventoryArea));
        statsPanel.setVisible(false); // Initially hidden

        mainCenterPanel.add(statsPanel, BorderLayout.CENTER); // Lists below question/image panel

        panel.add(mainCenterPanel, BorderLayout.CENTER); // Add main center panel to frame panel

        // --- Button Panel at the Bottom ---
        // (No changes needed here)
        buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        yesButton = new JButton("Yes");
        noButton = new JButton("No");
        yesButton.setPreferredSize(new Dimension(80, 30));
        noButton.setPreferredSize(new Dimension(80, 30));
        yesButton.addActionListener(this::handleYes);
        noButton.addActionListener(this::handleNo);
        buttonPanel.add(yesButton);
        buttonPanel.add(noButton);
        viewCharactersButton = new JButton("View Saved Characters");
        viewCharactersButton.setPreferredSize(new Dimension(180, 30));
        viewCharactersButton.addActionListener(this::handleViewCharacters);
        buttonPanel.add(viewCharactersButton);
        createAnotherButton = new JButton("Create Another");
        exitButton = new JButton("Exit");
        createAnotherButton.setPreferredSize(new Dimension(140, 30));
        exitButton.setPreferredSize(new Dimension(80, 30));
        createAnotherButton.addActionListener(this::handleCreateAnother);
        exitButton.addActionListener(this::handleExit);
        buttonPanel.add(createAnotherButton);
        buttonPanel.add(exitButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);
    }

    // --- Action Handlers ---
    // (No changes needed in handlers: startCreationProcess, handleYes, handleNo,
    // handleCreateAnother, handleExit, handleViewCharacters)
    private void startCreationProcess(ActionEvent e) {
        String name = nameField.getText();
        if (name == null || name.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter a character name first.", "Name Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        nameField.setEnabled(false);
        updateQuestion(rootQuestion);
    }
    private void handleYes(ActionEvent e) {
        if (!nameField.isEnabled()) {
             if (currentQuestion != null && currentQuestion.yes != null) {
                 updateQuestion(currentQuestion.yes);
             }
        } else {
             startCreationProcess(null);
        }
    }
    private void handleNo(ActionEvent e) {
        if (!nameField.isEnabled()) {
            if (currentQuestion != null && currentQuestion.no != null) {
                updateQuestion(currentQuestion.no);
            }
        } else {
             startCreationProcess(null);
        }
    }
    private void handleCreateAnother(ActionEvent e) {
        resetCharacter();
    }
    private void handleExit(ActionEvent e) {
        frame.dispose();
        System.exit(0);
    }
    private void handleViewCharacters(ActionEvent e) {
        new CharacterListView();
    }


    // --- Core Logic Methods ---

    private void updateQuestion(QuestionNode node) {
        if (node == null) {
             System.err.println("Error: Tried to update to a null node.");
             return;
        }
        currentQuestion = node;

        if(node.skillsToAdd != null){
            characterSkills.addAll(node.skillsToAdd);
        }
        if(node.itemsToAdd != null){
            characterInventory.addAll(node.itemsToAdd);
        }

        updateDisplayLists(); // Update text areas even during questions

        if(node.charClass != null){ // Final node
            characterClass = node.charClass;
            // Don't set questionLabel text here, createCharacter will handle it
            createCharacter(); // Trigger final creation steps
        } else { // Intermediate question
            questionLabel.setText("<html><center>" + currentQuestion.question + "</center></html>");
            // Hide image and stats during questions
            classImageLabel.setVisible(false);
            statsPanel.setVisible(false);
            // Show/Hide appropriate buttons
            yesButton.setEnabled(true);
            noButton.setEnabled(true);
            yesButton.setVisible(true);
            noButton.setVisible(true);
            createAnotherButton.setVisible(false);
            exitButton.setVisible(false); // Hide exit during questions? Or keep visible? User choice.
            viewCharactersButton.setVisible(true);
            frame.pack(); // Adjust size if needed
        }
    }

    // --- Definition for updateDisplayLists Method ---
    // (No changes needed)
    private void updateDisplayLists() {
        skillsArea.setText(formatListForDisplay(characterSkills));
        skillsArea.setCaretPosition(0);
        inventoryArea.setText(formatListForDisplay(characterInventory));
        inventoryArea.setCaretPosition(0);
    }
    // --- END Definition ---

    // --- Definition for createBinaryTree Method ---
    // (No changes needed)
    private void createBinaryTree() {
        List<String> warriorSkills = Arrays.asList("Power Strike", "Shield Block");
        List<String> warriorItems = Arrays.asList("Plate Mail", "Kite Shield");
        QuestionNode finalWarrior = new QuestionNode("You stand ready as a stalwart Warrior!", warriorSkills, warriorItems, "Warrior");
        List<String> wizardSkills = Arrays.asList("Fireball", "Arcane Bolt");
        List<String> wizardItems = Arrays.asList("Wizard Robes", "Spellbook");
        QuestionNode finalWizard = new QuestionNode("The arcane energies flow through you, Wizard!", wizardSkills, wizardItems, "Wizard");
        List<String> thiefStealthSkills = Arrays.asList("Backstab", "Poison Use");
        List<String> thiefStealthItems = Arrays.asList("Stiletto", "Black Cloak");
        QuestionNode finalThiefStealth = new QuestionNode("You fade into the shadows... a true Thief!", thiefStealthSkills, thiefStealthItems, "Thief");
        List<String> thiefCombatSkills = Arrays.asList("Evasion", "Rapid Strikes");
        List<String> thiefCombatItems = Arrays.asList("Leather Jerkin", "Weighted Gloves");
        QuestionNode finalThiefCombat = new QuestionNode("Fast and deadly, you strike like a viper! (Class: Thief)", thiefCombatSkills, thiefCombatItems, "Thief");
        List<String> defaultSkills = Arrays.asList("First Aid", "Endurance");
        List<String> defaultItems = Arrays.asList("Traveler's Pack", "Short Bow");
        QuestionNode finalDefault = new QuestionNode("Ready for anything, the life of an Adventurer awaits! (Class: Warrior)", defaultSkills, defaultItems, "Warrior");
        QuestionNode q4_no = new QuestionNode("Do you prefer relying on your fists and agility?", Arrays.asList("Unarmed Strike"), null);
        q4_no.yes = finalThiefCombat;
        q4_no.no = finalDefault;
        QuestionNode q1_yes = new QuestionNode("Will you rely on well-crafted weapons?", null, Arrays.asList("Basic Sword"));
        q1_yes.yes = finalWarrior;
        q1_yes.no = q4_no;
        QuestionNode q1 = new QuestionNode("Do you prefer engaging foes up close in combat?");
        q1.yes = q1_yes;
        QuestionNode q3_yes = new QuestionNode("Will you use your stealth for surprise attacks?", Arrays.asList("Stealth"), Arrays.asList("Dagger"));
        q3_yes.yes = finalThiefStealth;
        q3_yes.no = finalThiefStealth;
        QuestionNode q3 = new QuestionNode("Do you prefer operating unseen from the shadows (stealth)?");
        q3.yes = q3_yes;
        QuestionNode q3_no = new QuestionNode("Do you consider yourself a jack-of-all-trades, ready for adventure?");
        q3_no.yes = finalDefault;
        q3_no.no = finalDefault;
        q3.no = q3_no;
        QuestionNode q2_yes = new QuestionNode("Will you focus on destructive elemental magic?", null, Arrays.asList("Magic Staff"));
        q2_yes.yes = finalWizard;
        q2_yes.no = finalWizard;
        QuestionNode q2 = new QuestionNode("Are you drawn to the power of the arcane arts (magic)?");
        q2.yes = q2_yes;
        q2.no = q3;
        q1.no = q2;
        rootQuestion = q1;
    }
    // --- END Definition ---

    // **** MODIFIED createCharacter ****
    private void createCharacter(){
        String name = nameField.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Character name is missing.", "Error", JOptionPane.ERROR_MESSAGE);
            resetCharacter();
            return;
        }

        // Assign base stats
        switch (characterClass) {
            case "Warrior":
                characterStrength = 10; characterIntelligence = 2; characterAgility = 6;
                break;
            case "Wizard":
                characterStrength = 2; characterIntelligence = 10; characterAgility = 6;
                break;
            case "Thief":
                characterStrength = 6; characterIntelligence = 2; characterAgility = 10;
                break;
            default:
                System.err.println("Error: Unknown character class '" + characterClass + "' determined.");
                JOptionPane.showMessageDialog(frame, "An error occurred during character creation (Unknown Class: " + characterClass + ").", "Error", JOptionPane.ERROR_MESSAGE);
                // Show post-creation buttons even on error
                yesButton.setVisible(false); noButton.setVisible(false);
                viewCharactersButton.setVisible(true); createAnotherButton.setVisible(true); exitButton.setVisible(true);
                classImageLabel.setVisible(false); // Ensure image is hidden on error too
                statsPanel.setVisible(false);
                frame.pack();
                return;
        }

        // --- Load and Display Class Image ---
        ImageIcon finalIcon = null;
        try {
            String imagePath = "/images/" + characterClass.toLowerCase() + ".jpg"; // Assumes src/images/classname.png
            URL imageURL = getClass().getResource(imagePath);

            if (imageURL != null) {
                ImageIcon originalIcon = new ImageIcon(imageURL);
                // Scale the image
                Image image = originalIcon.getImage();
                // Adjust targetWidth and targetHeight as desired
                int targetWidth = 120;
                int targetHeight = 120;
                Image scaledImage = image.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
                finalIcon = new ImageIcon(scaledImage);
                classImageLabel.setIcon(finalIcon);
                classImageLabel.setVisible(true);
            } else {
                System.err.println("Warning: Could not find image resource: " + imagePath);
                classImageLabel.setIcon(null);
                classImageLabel.setVisible(false);
            }
        } catch (Exception ex) {
            System.err.println("Error loading or scaling image: " + ex.getMessage());
            classImageLabel.setIcon(null);
            classImageLabel.setVisible(false);
        }
        // --- End Image Loading ---


        // Set final text details (now includes HTML for line breaks)
        String resultText = String.format(
            "<html><center>Character Created!<br>" +
            "Name: %s<br>" +
            "Class: %s<br><br>" +
            "Strength: %d | Intelligence: %d | Agility: %d" +
            "</center></html>",
            name, characterClass, characterStrength, characterIntelligence, characterAgility
        );
        questionLabel.setText(resultText);

        // Show final skills/inventory lists
        updateDisplayLists(); // Ensure lists are up-to-date
        statsPanel.setVisible(true); // Show the lists panel

        // Save character via controller
        Character character = controller.createCharacter(
            characterClass, name, characterStrength, characterIntelligence,
            characterAgility, characterSkills, characterInventory
        );

        // --- Post-Creation Flow ---
        yesButton.setVisible(false);
        noButton.setVisible(false);
        viewCharactersButton.setVisible(true);
        createAnotherButton.setVisible(true);
        exitButton.setVisible(true);
        nameField.setEnabled(false);
        frame.pack(); // Resize frame to fit image and final content
        // --- End Post-Creation Flow ---

        // Show success/failure message AFTER UI updates
        if (character != null) {
            JOptionPane.showMessageDialog(frame, "Character '" + name + "' saved successfully!", "Character Saved", JOptionPane.INFORMATION_MESSAGE);
        } else {
             JOptionPane.showMessageDialog(frame, "Failed to save character '" + name + "' to the database.", "Save Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    // **** END MODIFICATION ****


    // --- Definition for formatListForDisplay Method ---
    // (No changes needed)
    private String formatListForDisplay(List<String> list) {
        if (list == null || list.isEmpty()) return "  (None)";
        StringBuilder sb = new StringBuilder();
        for (String item : list) {
            sb.append("  - ").append(item).append("\n");
        }
        return sb.toString();
    }
    // --- END Definition ---

    // **** MODIFIED resetCharacter ****
     private void resetCharacter(){
        // Clear internal state
        characterSkills.clear();
        characterInventory.clear();
        characterClass = null;
        characterStrength = 0; characterIntelligence = 0; characterAgility = 0;

        // Reset UI components
        nameField.setText("");
        nameField.setEnabled(true);
        questionLabel.setText("Enter Name and Press Enter or Click 'Yes'/'No' below");
        updateDisplayLists();
        statsPanel.setVisible(false); // Hide lists panel
        classImageLabel.setIcon(null); // Remove image
        classImageLabel.setVisible(false); // Hide image label

        // Reset button visibility
        yesButton.setVisible(true); noButton.setVisible(true);
        yesButton.setEnabled(true); noButton.setEnabled(true);
        createAnotherButton.setVisible(false); exitButton.setVisible(false);
        viewCharactersButton.setVisible(true);

        currentQuestion = rootQuestion;

        nameField.requestFocusInWindow();
        frame.pack(); // Resize frame back to normal
    }
    // **** END MODIFICATION ****


    // Main method - Entry point
    // (No changes needed)
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                System.err.println("Couldn't set system look and feel: " + e.getMessage());
            }
            new MainView();
        });
    }
} // End of MainView class
