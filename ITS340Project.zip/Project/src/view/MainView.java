package view;

import controller.CharacterCreationController;
import java.awt.*; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL; 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.*; 
import model.Character;
import model.Item; 
import model.QuestionNode;

public class MainView {
    private JFrame frame;
    private JTextField nameField;
    private JLabel questionLabel;
    private JButton yesButton;
    private JButton noButton;
    private JButton createAnotherButton;
    private JButton exitButton;
    private JButton viewCharactersButton;
    private JPanel panel;
    private JPanel buttonPanel;
    private JTextArea skillsArea;
    private JTextArea inventoryArea;
    private JPanel questionPanel; 
    private JPanel statsPanel;    

    
    private JLabel classImageLabel;
    

    private QuestionNode rootQuestion;
    private QuestionNode currentQuestion;
    private CharacterCreationController controller;
    private List<String> characterSkills = new ArrayList<>();
    private List<String> characterInventory = new ArrayList<>();
    private String characterClass;
    private int characterStrength;
    private int characterIntelligence;
    private int characterAgility;

    
    private Character characterToEdit = null;
    private CharacterListView listViewCallback = null;
    private boolean isEditMode = false;

    
    public MainView() {
        this.isEditMode = false;
        initializeFrame();
        this.controller = new CharacterCreationController();
        createBinaryTree(); 
        placeComponents();
        resetCharacter(); 
        frame.setVisible(true);
    }

    
    public MainView(Character characterToEdit, CharacterListView listViewCallback) {
        this.isEditMode = true;
        this.characterToEdit = characterToEdit;
        this.listViewCallback = listViewCallback;
        initializeFrame();
        this.controller = new CharacterCreationController(); 
        
        placeComponents(); 
        setupForEditMode(); 
        frame.setVisible(true);
    }

    private void initializeFrame() {
        frame = new JFrame("RPG Character Creator"); 
        frame.setSize(600, 550); 
        
        frame.setDefaultCloseOperation(isEditMode ? JFrame.DISPOSE_ON_CLOSE : JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        panel = new JPanel();
        frame.add(panel);
        panel.setLayout(new BorderLayout());
    }

    private void placeComponents() {
        
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JLabel nameLabel = new JLabel("Character Name:");
        nameField = new JTextField(20);
        
        topPanel.add(nameLabel);
        topPanel.add(nameField);
        panel.add(topPanel, BorderLayout.NORTH);

        
        
        JPanel mainCenterPanel = new JPanel(new BorderLayout(0, 10));
        mainCenterPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        
        questionPanel = new JPanel(new BorderLayout(5, 5)); 

        
        classImageLabel = new JLabel();
        classImageLabel.setHorizontalAlignment(JLabel.CENTER);
        classImageLabel.setVerticalAlignment(JLabel.CENTER);
        classImageLabel.setPreferredSize(new Dimension(150, 150)); 
        classImageLabel.setVisible(false); 
        questionPanel.add(classImageLabel, BorderLayout.NORTH); 
        

        questionLabel = new JLabel("Enter Name and Press Enter or Click 'Yes'/'No' below", JLabel.CENTER);
        questionLabel.setFont(new Font("Arial", Font.BOLD, 14));
        questionLabel.setHorizontalAlignment(JLabel.CENTER);
        questionPanel.add(questionLabel, BorderLayout.CENTER); 

        mainCenterPanel.add(questionPanel, BorderLayout.NORTH); 

        
        statsPanel = new JPanel(new GridLayout(1, 2, 15, 0)); 
        skillsArea = new JTextArea(8, 18);
        skillsArea.setEditable(false);
        skillsArea.setLineWrap(true);
        skillsArea.setWrapStyleWord(true);
        skillsArea.setBorder(BorderFactory.createTitledBorder("Skills Acquired"));
        inventoryArea = new JTextArea(8, 18);
        inventoryArea.setEditable(false);
        inventoryArea.setLineWrap(true);
        inventoryArea.setWrapStyleWord(true);
        inventoryArea.setBorder(BorderFactory.createTitledBorder("Inventory Acquired"));

        statsPanel.add(new JScrollPane(skillsArea));
        statsPanel.add(new JScrollPane(inventoryArea));
        statsPanel.setVisible(false); 

        mainCenterPanel.add(statsPanel, BorderLayout.CENTER); 

        panel.add(mainCenterPanel, BorderLayout.CENTER); 

        
        
        buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        yesButton = new JButton("Yes");
        noButton = new JButton("No");
        yesButton.setPreferredSize(new Dimension(80, 30));
        noButton.setPreferredSize(new Dimension(80, 30));
        
        viewCharactersButton = new JButton("View Saved Characters");
        viewCharactersButton.setPreferredSize(new Dimension(180, 30));
        
        createAnotherButton = new JButton("Create Another"); 
        exitButton = new JButton("Exit"); 
        createAnotherButton.setPreferredSize(new Dimension(140, 30));
        exitButton.setPreferredSize(new Dimension(80, 30));

        if (isEditMode) {
            nameField.addActionListener(null); 

            createAnotherButton.setText("Save Changes");
            
            for(ActionListener al : createAnotherButton.getActionListeners()) { createAnotherButton.removeActionListener(al); }
            createAnotherButton.addActionListener(this::handleSaveChanges);

            exitButton.setText("Cancel");
            for(ActionListener al : exitButton.getActionListeners()) { exitButton.removeActionListener(al); }
            exitButton.addActionListener(e -> frame.dispose());

            
            yesButton.setVisible(false);
            noButton.setVisible(false);
            viewCharactersButton.setVisible(false);
        } else {
            nameField.addActionListener(this::startCreationProcess);
            yesButton.addActionListener(this::handleYes);
            noButton.addActionListener(this::handleNo);
            viewCharactersButton.addActionListener(this::handleViewCharacters);
            createAnotherButton.addActionListener(this::handleCreateAnother);
            exitButton.addActionListener(this::handleExit);

            buttonPanel.add(yesButton);
            buttonPanel.add(noButton);
            buttonPanel.add(viewCharactersButton);
        }
        
        buttonPanel.add(createAnotherButton);
        buttonPanel.add(exitButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);
    }

    
    
    
    private void startCreationProcess(ActionEvent e) {
        if (isEditMode) return; 
        String name = nameField.getText();
        if (name == null || name.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter a character name first.", "Name Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        nameField.setEnabled(false);
        updateQuestion(rootQuestion);
    }
    private void handleYes(ActionEvent e) {
        if (isEditMode) return;
        if (!nameField.isEnabled()) {
             if (currentQuestion != null && currentQuestion.yes != null) {
                 updateQuestion(currentQuestion.yes);
             }
        } else {
             startCreationProcess(null);
        }
    }
    private void handleNo(ActionEvent e) {
        if (isEditMode) return;
        if (!nameField.isEnabled()) {
            if (currentQuestion != null && currentQuestion.no != null) {
                updateQuestion(currentQuestion.no);
            }
        } else {
             startCreationProcess(null);
        }
    }
    private void handleCreateAnother(ActionEvent e) {
        if (isEditMode) return; 
        resetCharacter();
    }
    private void handleExit(ActionEvent e) {
        
        if (isEditMode) { 
            frame.dispose(); 
            return; 
        }
        frame.dispose();
        System.exit(0);
    }
    private void handleViewCharacters(ActionEvent e) {
        if (isEditMode) return;
        new CharacterListView();
    }


    

    private void updateQuestion(QuestionNode node) {
        if (isEditMode) return; 
        if (node == null) {
             System.err.println("Error: Tried to update to a null node.");
             return;
        }
        currentQuestion = node;

        if(node.skillsToAdd != null){
            characterSkills.addAll(node.skillsToAdd);
        }
        if(node.itemsToAdd != null){
            characterInventory.addAll(node.itemsToAdd);
        }

        updateDisplayLists(); 

        if(node.charClass != null){ 
            characterClass = node.charClass;
            
            createCharacter(); 
        } else { 
            questionLabel.setText("<html><center>" + currentQuestion.question + "</center></html>");
            
            displayCharacterImage(null); 
            statsPanel.setVisible(false);
            
            yesButton.setEnabled(true);
            noButton.setEnabled(true);
            yesButton.setVisible(true);
            noButton.setVisible(true);
            createAnotherButton.setVisible(false);
            exitButton.setVisible(false); 
            viewCharactersButton.setVisible(true);
            frame.pack(); 
        }
    }

    
    
    private void updateDisplayLists() {
        skillsArea.setText(formatListForDisplay(characterSkills));
        skillsArea.setCaretPosition(0);
        inventoryArea.setText(formatListForDisplay(characterInventory));
        inventoryArea.setCaretPosition(0);
    }
    

    
    
    private void createBinaryTree() {
        if (isEditMode) return; 
        List<String> warriorSkills = Arrays.asList("Power Strike", "Shield Block");
        List<String> warriorItems = Arrays.asList("Plate Mail", "Kite Shield");
        QuestionNode finalWarrior = new QuestionNode("You stand ready as a stalwart Warrior!", warriorSkills, warriorItems, "Warrior");
        List<String> wizardSkills = Arrays.asList("Fireball", "Arcane Bolt");
        List<String> wizardItems = Arrays.asList("Wizard Robes", "Spellbook");
        QuestionNode finalWizard = new QuestionNode("The arcane energies flow through you, Wizard!", wizardSkills, wizardItems, "Wizard");
        List<String> thiefStealthSkills = Arrays.asList("Backstab", "Poison Use");
        List<String> thiefStealthItems = Arrays.asList("Stiletto", "Black Cloak");
        QuestionNode finalThiefStealth = new QuestionNode("You fade into the shadows... a true Thief!", thiefStealthSkills, thiefStealthItems, "Thief");
        List<String> thiefCombatSkills = Arrays.asList("Evasion", "Rapid Strikes");
        List<String> thiefCombatItems = Arrays.asList("Leather Jerkin", "Weighted Gloves");
        QuestionNode finalThiefCombat = new QuestionNode("Fast and deadly, you strike like a viper! (Class: Thief)", thiefCombatSkills, thiefCombatItems, "Thief");
        List<String> defaultSkills = Arrays.asList("First Aid", "Endurance");
        List<String> defaultItems = Arrays.asList("Traveler's Pack", "Short Bow");
        QuestionNode finalDefault = new QuestionNode("Ready for anything, the life of an Adventurer awaits! (Class: Warrior)", defaultSkills, defaultItems, "Warrior");
        QuestionNode q4_no = new QuestionNode("Do you prefer relying on your fists and agility?", Arrays.asList("Unarmed Strike"), null);
        q4_no.yes = finalThiefCombat;
        q4_no.no = finalDefault;
        QuestionNode q1_yes = new QuestionNode("Will you rely on well-crafted weapons?", null, Arrays.asList("Basic Sword"));
        q1_yes.yes = finalWarrior;
        q1_yes.no = q4_no;
        QuestionNode q1 = new QuestionNode("Do you prefer engaging foes up close in combat?");
        q1.yes = q1_yes;
        QuestionNode q3_yes = new QuestionNode("Will you use your stealth for surprise attacks?", Arrays.asList("Stealth"), Arrays.asList("Dagger"));
        q3_yes.yes = finalThiefStealth;
        q3_yes.no = finalThiefStealth;
        QuestionNode q3 = new QuestionNode("Do you prefer operating unseen from the shadows (stealth)?");
        q3.yes = q3_yes;
        QuestionNode q3_no = new QuestionNode("Do you consider yourself a jack-of-all-trades, ready for adventure?");
        q3_no.yes = finalDefault;
        q3_no.no = finalDefault;
        q3.no = q3_no;
        QuestionNode q2_yes = new QuestionNode("Will you focus on destructive elemental magic?", null, Arrays.asList("Magic Staff"));
        q2_yes.yes = finalWizard;
        q2_yes.no = finalWizard;
        QuestionNode q2 = new QuestionNode("Are you drawn to the power of the arcane arts (magic)?");
        q2.yes = q2_yes;
        q2.no = q3;
        q1.no = q2;
        rootQuestion = q1;
    }
    

    
    private void createCharacter(){
        if (isEditMode) return; 
        String name = nameField.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Character name is missing.", "Error", JOptionPane.ERROR_MESSAGE);
            resetCharacter();
            return;
        }

        
        switch (characterClass) {
            case "Warrior":
                characterStrength = 10; characterIntelligence = 2; characterAgility = 6;
                break;
            case "Wizard":
                characterStrength = 2; characterIntelligence = 10; characterAgility = 6;
                break;
            case "Thief":
                characterStrength = 6; characterIntelligence = 2; characterAgility = 10;
                break;
            default:
                System.err.println("Error: Unknown character class '" + characterClass + "' determined.");
                JOptionPane.showMessageDialog(frame, "An error occurred during character creation (Unknown Class: " + characterClass + ").", "Error", JOptionPane.ERROR_MESSAGE);
                
                yesButton.setVisible(false); noButton.setVisible(false);
                viewCharactersButton.setVisible(true); createAnotherButton.setVisible(true); exitButton.setVisible(true);
                displayCharacterImage(null); 
                statsPanel.setVisible(false);
                frame.pack();
                return;
        }

        displayCharacterImage(this.characterClass);
        
        String resultText = String.format(
            "<html><center>Character Created!<br>" +
            "Name: %s<br>" +
            "Class: %s<br><br>" +
            "Strength: %d | Intelligence: %d | Agility: %d" +
            "</center></html>",
            name, characterClass, characterStrength, characterIntelligence, characterAgility
        );
        questionLabel.setText(resultText);

        
        updateDisplayLists(); 
        statsPanel.setVisible(true); 

        
        Character character = controller.createCharacter(
            characterClass, name, characterStrength, characterIntelligence,
            characterAgility, characterSkills, characterInventory
        );

        
        yesButton.setVisible(false);
        noButton.setVisible(false);
        viewCharactersButton.setVisible(true);
        createAnotherButton.setVisible(true);
        exitButton.setVisible(true);
        nameField.setEnabled(false);
        frame.pack(); 
        

        
        if (character != null) {
            JOptionPane.showMessageDialog(frame, "Character '" + name + "' saved successfully!", "Character Saved", JOptionPane.INFORMATION_MESSAGE);
        } else {
             JOptionPane.showMessageDialog(frame, "Failed to save character '" + name + "' to the database.", "Save Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void setupForEditMode() {
        if (characterToEdit == null) return;

        frame.setTitle("Edit Character: " + characterToEdit.getName());
        nameField.setText(characterToEdit.getName());
        

        questionLabel.setText("<html><center>Editing Character: " + characterToEdit.getName() + 
                              "<br>Class: " + characterToEdit.getCharClass() + " (Class cannot be changed)</center></html>");

        
        this.characterClass = characterToEdit.getCharClass();
        this.characterStrength = characterToEdit.getStrength();
        this.characterIntelligence = characterToEdit.getIntelligence();
        this.characterAgility = characterToEdit.getAgility();

        characterSkills.clear();
        if (characterToEdit.getSkills() != null) {
            characterSkills.addAll(characterToEdit.getSkills());
        }
        characterInventory.clear();
        if (characterToEdit.getInventory() != null) {
            for (Item item : characterToEdit.getInventory()) {
                characterInventory.add(item.getName()); 
            }
        }

        updateDisplayLists();
        statsPanel.setVisible(true);
        displayCharacterImage(this.characterClass);

        
        
        yesButton.setVisible(false);
        noButton.setVisible(false);
        viewCharactersButton.setVisible(false);
        createAnotherButton.setVisible(true); 
        exitButton.setVisible(true); 

        frame.pack();
    }

    private void handleSaveChanges(ActionEvent e) {
        if (!isEditMode || characterToEdit == null) return;

        String newName = nameField.getText().trim();
        if (newName.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Character name cannot be empty.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        characterToEdit.setName(newName);
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        characterToEdit.setSkills(new ArrayList<>(this.characterSkills)); 
        List<Item> updatedItems = controller.getItemsByNames(this.characterInventory); 
        characterToEdit.setInventory(updatedItems);
        

        Character result = controller.updateCharacter(characterToEdit);
        if (result != null) {
            JOptionPane.showMessageDialog(frame, "Character '" + result.getName() + "' updated successfully!", "Update Successful", JOptionPane.INFORMATION_MESSAGE);
            if (listViewCallback != null) {
                listViewCallback.refreshCharacterListOnUpdate();
            }
            frame.dispose();
        } else {
            JOptionPane.showMessageDialog(frame, "Failed to update character '" + characterToEdit.getName() + "'.", "Update Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

    
    
    private String formatListForDisplay(List<String> list) {
        if (list == null || list.isEmpty()) return "  (None)";
        StringBuilder sb = new StringBuilder();
        for (String item : list) {
            sb.append("  - ").append(item).append("\n");
        }
        return sb.toString();
    }
    

    
     private void resetCharacter(){
        if (isEditMode) return; 
        
        characterSkills.clear();
        characterInventory.clear();
        characterClass = null;
        characterStrength = 0; characterIntelligence = 0; characterAgility = 0;

        
        nameField.setText("");
        nameField.setEnabled(true);
        questionLabel.setText("Enter Name and Press Enter or Click 'Yes'/'No' below");
        updateDisplayLists();
        statsPanel.setVisible(false); 
        displayCharacterImage(null); 

        
        yesButton.setVisible(true); noButton.setVisible(true);
        yesButton.setEnabled(true); noButton.setEnabled(true);
        createAnotherButton.setVisible(false); exitButton.setVisible(false);
        viewCharactersButton.setVisible(true);

        currentQuestion = rootQuestion;

        nameField.requestFocusInWindow();
        frame.pack(); 
    }
    
    private void displayCharacterImage(String charClassForImage) {
        if (charClassForImage == null || charClassForImage.trim().isEmpty()) {
             classImageLabel.setIcon(null);
             classImageLabel.setVisible(false);
             frame.pack(); 
             return;
        }
        ImageIcon finalIcon = null;
        try {
            String imagePath = "/images/" + charClassForImage.toLowerCase() + ".jpg";
            URL imageURL = getClass().getResource(imagePath);

            if (imageURL != null) {
                ImageIcon originalIcon = new ImageIcon(imageURL);
                Image image = originalIcon.getImage();
                
                Image scaledImage = image.getScaledInstance(classImageLabel.getPreferredSize().width, classImageLabel.getPreferredSize().height, Image.SCALE_SMOOTH);
                finalIcon = new ImageIcon(scaledImage);
            } else {
                System.err.println("MainView Warning: Could not find image resource: " + imagePath);
            }
        } catch (Exception ex) {
            System.err.println("MainView Error loading or scaling image: " + ex.getMessage());
        }
        classImageLabel.setIcon(finalIcon);
        classImageLabel.setVisible(finalIcon != null);
        frame.pack(); 
    }


    
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                System.err.println("Couldn't set system look and feel: " + e.getMessage());
            }
            new MainView();
        });
    }
}
