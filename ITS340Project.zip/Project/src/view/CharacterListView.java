package view;

import controller.CharacterCreationController;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.net.URL; 
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import model.Character;
import model.Item; 

public class CharacterListView implements ListSelectionListener {

    private final JFrame frame;
    private final JList<String> characterList;
    private final DefaultListModel<String> listModel;
    private final JTextArea detailsArea;
    private final CharacterCreationController controller;
    private final JButton deleteButton;
    private final JButton editButton; 
    private final JButton closeButton;
    private final List<Integer> characterIds;

    
    private final JLabel classImageLabel;
    

    public CharacterListView() {
        controller = new CharacterCreationController();
        characterIds = new ArrayList<>();

        frame = new JFrame("View Saved Characters");
        frame.setSize(700, 550); 
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout(10, 10));

        
        listModel = new DefaultListModel<>();
        characterList = new JList<>(listModel);
        detailsArea = new JTextArea();
        deleteButton = new JButton("Delete Selected");
        editButton = new JButton("Edit Selected"); 
        closeButton = new JButton("Close");

        
        classImageLabel = new JLabel();
        classImageLabel.setHorizontalAlignment(JLabel.CENTER);
        classImageLabel.setVerticalAlignment(JLabel.CENTER);
        
        classImageLabel.setPreferredSize(new Dimension(120, 120));
        classImageLabel.setVisible(false); 
        

        placeComponents();
        loadCharacterList();

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void placeComponents() {
        
        characterList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        characterList.addListSelectionListener(this);
        characterList.setBorder(BorderFactory.createTitledBorder("Characters"));
        JScrollPane listScrollPane = new JScrollPane(characterList);
        listScrollPane.setPreferredSize(new Dimension(200, 0));
        frame.add(listScrollPane, BorderLayout.WEST);

        
        JPanel centerPanel = new JPanel(new BorderLayout(5, 5)); 
        centerPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); 

        
        centerPanel.add(classImageLabel, BorderLayout.NORTH);

        
        detailsArea.setEditable(false);
        detailsArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        detailsArea.setBorder(BorderFactory.createTitledBorder("Details"));
        detailsArea.setText("Select a character from the list to view details.");
        JScrollPane detailsScrollPane = new JScrollPane(detailsArea);
        centerPanel.add(detailsScrollPane, BorderLayout.CENTER); 

        
        frame.add(centerPanel, BorderLayout.CENTER);
        


        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        deleteButton.setEnabled(false);
        editButton.setEnabled(false); 

        deleteButton.addActionListener(this::handleDeleteCharacter);
        editButton.addActionListener(this::handleEditCharacter); 

        bottomPanel.add(editButton); 
        bottomPanel.add(deleteButton);
        closeButton.addActionListener(e -> frame.dispose());
        bottomPanel.add(closeButton);
        frame.add(bottomPanel, BorderLayout.SOUTH);
    }

    private void loadCharacterList() {
        listModel.clear();
        characterIds.clear();
        detailsArea.setText("Select a character from the list to view details.");
        deleteButton.setEnabled(false);
        editButton.setEnabled(false);
        classImageLabel.setVisible(false); 

        Map<Integer, String> summaries = controller.loadAllCharacterSummaries();

        if (summaries.isEmpty()) {
            listModel.addElement("No characters found.");
            characterList.setEnabled(false);
        } else {
            summaries.entrySet().stream()
                     .sorted(Map.Entry.comparingByValue())
                     .forEach(entry -> {
                         listModel.addElement(entry.getValue());
                         characterIds.add(entry.getKey());
                     });
            characterList.setEnabled(true);
        }
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) {
            int selectedIndex = characterList.getSelectedIndex();
            if (selectedIndex != -1 && selectedIndex < characterIds.size()) {
                int selectedId = characterIds.get(selectedIndex);
                Character selectedCharacter = controller.loadCharacterDetails(selectedId);

                
                if (selectedCharacter != null) {
                    displayCharacterImage(selectedCharacter.getCharClass()); 
                    deleteButton.setEnabled(true);
                    editButton.setEnabled(true); 
                } else {
                    
                    classImageLabel.setIcon(null);
                    classImageLabel.setVisible(false);
                    deleteButton.setEnabled(false);
                    editButton.setEnabled(false); 
                }
                

                displayCharacterDetails(selectedCharacter); 

            } else {
                
                detailsArea.setText("Select a character from the list to view details.");
                deleteButton.setEnabled(false);
                editButton.setEnabled(false);
                classImageLabel.setIcon(null); 
                classImageLabel.setVisible(false);
            }
        }
    }

    
    private void displayCharacterImage(String characterClass) {
        if (characterClass == null || characterClass.trim().isEmpty()) {
             classImageLabel.setIcon(null);
             classImageLabel.setVisible(false);
             return;
        }

        ImageIcon finalIcon = null;
        try {
            
            String imagePath = "/images/" + characterClass.toLowerCase() + ".jpg";
            System.out.println("ListView: Attempting to load image: " + imagePath); 
            URL imageURL = getClass().getResource(imagePath);

            if (imageURL != null) {
                System.out.println("ListView: Image found at URL: " + imageURL); 
                ImageIcon originalIcon = new ImageIcon(imageURL);
                Image image = originalIcon.getImage();
                
                int targetWidth = 120;
                int targetHeight = 120;
                Image scaledImage = image.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
                finalIcon = new ImageIcon(scaledImage);
                classImageLabel.setIcon(finalIcon);
                classImageLabel.setVisible(true);
            } else {
                System.err.println("ListView Warning: Could not find image resource: " + imagePath);
                classImageLabel.setIcon(null);
                classImageLabel.setVisible(false);
            }
        } catch (Exception ex) {
            System.err.println("ListView Error loading or scaling image: " + ex.getMessage());
            ex.printStackTrace(); 
            classImageLabel.setIcon(null);
            classImageLabel.setVisible(false);
        }
    }
    


    private void displayCharacterDetails(Character character) {
        
        if (character == null) {
            detailsArea.setText("Could not load details for the selected character.");
            
            
            return;
        }

        
        StringBuilder details = new StringBuilder();
        details.append("ID:         ").append(character.getId()).append("\n");
        details.append("Name:       ").append(character.getName()).append("\n");
        details.append("Class:      ").append(character.getCharClass()).append("\n\n");
        details.append("--- Stats ---\n");
        details.append("Strength:   ").append(character.getStrength()).append("\n");
        details.append("Intelligence: ").append(character.getIntelligence()).append("\n");
        details.append("Agility:    ").append(character.getAgility()).append("\n\n");
        details.append("--- Skills ---\n");
        if (character.getSkills() == null || character.getSkills().isEmpty()) {
            details.append("  (None)\n");
        } else {
            for (String skill : character.getSkills()) {
                details.append("  - ").append(skill).append("\n");
            }
        }
        details.append("\n");
        details.append("--- Inventory ---\n");
        if (character.getInventory() == null || character.getInventory().isEmpty()) {
            details.append("  (None)\n");
        } else {
            for (Item item : character.getInventory()) {
                details.append("  - ").append(item.toString()).append("\n");
            }
        }

        detailsArea.setText(details.toString());
        detailsArea.setCaretPosition(0);
    }


    private void handleDeleteCharacter(ActionEvent e) {
        int selectedIndex = characterList.getSelectedIndex();
        if (selectedIndex == -1 || selectedIndex >= characterIds.size()) {
            JOptionPane.showMessageDialog(frame, "Please select a character to delete.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int selectedId = characterIds.get(selectedIndex);
        String selectedName = listModel.getElementAt(selectedIndex);
        int confirmation = JOptionPane.showConfirmDialog(
            frame,
            "Are you sure you want to permanently delete '" + selectedName + "' (ID: " + selectedId + ")?\nThis action cannot be undone.",
            "Confirm Deletion",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );
        if (confirmation == JOptionPane.YES_OPTION) {
            boolean success = controller.deleteCharacter(selectedId);
            if (success) {
                JOptionPane.showMessageDialog(frame, "'" + selectedName + "' was successfully deleted.", "Deletion Successful", JOptionPane.INFORMATION_MESSAGE);
                loadCharacterList(); 
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to delete '" + selectedName + "'. Check console logs for details.", "Deletion Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleEditCharacter(ActionEvent e) {
        int selectedIndex = characterList.getSelectedIndex();
        if (selectedIndex == -1 || selectedIndex >= characterIds.size()) {
            JOptionPane.showMessageDialog(frame, "Please select a character to edit.", "No Character Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int selectedId = characterIds.get(selectedIndex);
        Character characterToEdit = controller.loadCharacterDetails(selectedId);

        if (characterToEdit != null) {
            
            
            
            
            System.out.println("Opening MainView in edit mode for character ID: " + selectedId);
            
            new MainView(characterToEdit, this); 
            
        } else {
            JOptionPane.showMessageDialog(frame, "Could not load details for the selected character to edit.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    public void refreshCharacterListOnUpdate() {
        loadCharacterList();
    }
}

