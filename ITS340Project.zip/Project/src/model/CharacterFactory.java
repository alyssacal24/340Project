package model;



public class CharacterFactory {

    
    public static Character createCharacter(String type, String name) {
        if (type == null || name == null) {
            return null; 
        }
        return switch (type.toLowerCase()) {
            case "warrior" -> new Warrior(name);
            case "wizard" -> new Wizard(name);
            case "thief" -> new Thief(name);
            default -> {
                System.err.println("Warning: Unknown character type requested: " + type);
                yield null; 
            }
        };
    }


}
