package model; 

public class Thief extends Character {
    public Thief(String name) {
        
        super(name, "Thief"); 
    }

    
    
}

