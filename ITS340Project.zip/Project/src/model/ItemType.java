
package model;

public enum ItemType {
    WEAPON("Weapon"),
    ARMOR("Armor"),
    POTION("Potion"),
    QUEST("Quest Item"),
    GENERIC("Generic Item"); 

    private final String displayName;

    ItemType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    
    public static ItemType fromString(String text) {
        for (ItemType b : ItemType.values()) {
            if (b.name().equalsIgnoreCase(text) || b.displayName.equalsIgnoreCase(text)) {
                return b;
            }
        }
        
        System.err.println("Warning: Unknown ItemType string: " + text + ". Defaulting to GENERIC.");
        return GENERIC;
    }
}
