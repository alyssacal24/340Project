package model;

import java.util.ArrayList;
import java.util.List;

public abstract class Character {

    protected int id;
    protected String name;
    protected String charClass;
    protected int strength;
    protected int intelligence;
    protected int agility;
    protected List<String> skills;
    protected List<Item> inventory; 

    public Character(String name, String charClass) {
        this.name = name;
        this.charClass = charClass;
        this.skills = new ArrayList<>();
        this.inventory = new ArrayList<>(); 
        this.strength = 0; 
        this.intelligence = 0;
        this.agility = 0;
    }

    
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCharClass() {
        return charClass;
    }

    public int getStrength() {
        return strength;
    }

    public int getIntelligence() {
        return intelligence;
    }

    public int getAgility() {
        return agility;
    }

    public List<String> getSkills() {
        
        return new ArrayList<>(skills);
    }
    

    
    public List<Item> getInventory() {
        
        return new ArrayList<>(inventory);
    }

    public void setInventory(List<Item> inventory) {
        
        this.inventory = (inventory != null) ? new ArrayList<>(inventory) : new ArrayList<>();
    }
    


    
    public void setId(int id) {
        this.id = id;
    }


    public void setName(String name) {
        this.name = name;
    }
    

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public void setIntelligence(int intelligence) {
        this.intelligence = intelligence;
    }

    public void setAgility(int agility) {
        this.agility = agility;
    }

    public void setSkills(List<String> skills) {
        
        this.skills = (skills != null) ? new ArrayList<>(skills) : new ArrayList<>();
    }
    

    
}
