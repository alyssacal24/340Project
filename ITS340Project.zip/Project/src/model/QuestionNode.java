package model;

import java.util.List;

public class QuestionNode {
    public String question;
    public QuestionNode yes;
    public QuestionNode no;
    public List<String> skillsToAdd;
    public List<String> itemsToAdd;
    public String charClass;

    
    public QuestionNode(String question) {
        this.question = question;
        this.skillsToAdd = null; 
        this.itemsToAdd = null;
        this.charClass = null;
        this.yes = null;
        this.no = null;
    }

    

    public QuestionNode(String question, List<String> skillsToAdd, List<String> itemsToAdd) {
        this.question = question;
        this.skillsToAdd = skillsToAdd;
        this.itemsToAdd = itemsToAdd;
        this.charClass = null; 
        this.yes = null;       
        this.no = null;        
    }
    

    
    public QuestionNode(String question, List<String> skillsToAdd, List<String> itemsToAdd, String charClass){
        this.question = question;
        this.skillsToAdd = skillsToAdd;
        this.itemsToAdd = itemsToAdd;
        this.charClass = charClass;
        this.yes = null; 
        this.no = null;
    }
}
