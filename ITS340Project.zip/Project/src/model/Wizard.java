package model; 

public class Wizard extends Character {
    public Wizard(String name) {
        
        super(name, "Wizard"); 
    }

    
}
