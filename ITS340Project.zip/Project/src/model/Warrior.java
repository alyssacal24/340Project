package model; 

public class Warrior extends Character {
    public Warrior(String name) {
        
        super(name, "Warrior"); 
    }

    
}
